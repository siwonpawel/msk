#!/usr/bin/python3

import matplotlib.pyplot as plt
import pandas as pd
#
# amdhal = pd.read_csv('amdahal_old.csv', dtype=float)
#
# amdhal['t'] = amdhal['ts'] + amdhal['tp']
# amdhal['sp'] = amdhal['t'] / amdhal['tp']
# amdhal['f'] = amdhal['ts'] / amdhal['t']
# amdhal['sp'] = amdhal['t'][0] / amdhal['tp']
#
# f = 1 / amdhal['f'][0]
# print(f)
#
# plt.xlabel('P')
# plt.ylabel('f')
#
# plt.plot(amdhal['p'], amdhal['sp'])
# plt.axhline(y=f, color='r', linestyle='--')
# plt.title('Amdahal')
# plt.show()
#
# print(amdhal)
#
#
# gustafson = pd.read_csv('gustafson_old.csv')
# gustafson['t0'] = gustafson['ts0'] + gustafson['tp0']
# gustafson['f0'] = gustafson['ts0'] / gustafson['tp0']
#
# gustafson['t16'] = gustafson['ts16'] + gustafson['tp16']
# gustafson['f16'] = gustafson['ts16'] / gustafson['t16']
#
# gustafson['sp'] = gustafson['t0'] / gustafson['t16']
#
# plt.ylabel('S(P)')
# plt.xlabel('n')
# plt.plot(gustafson['n'], gustafson['sp'])
# plt.axhline(y=16, color='r', linestyle='--')
# plt.title('Gustafson')
# plt.show()
#
# plt.figure()
# plt.plot(gustafson['n'], gustafson['f0'], label='f')
# plt.xlabel('n')
# plt.ylabel('f')
# plt.title('Zależność wielkości części sekwencyjnej od wielkości problemu')
# plt.legend()
# plt.show()
#
# print(gustafson)



# lab 05
#
# plt.figure()
# gustafson = pd.read_csv('gustafson.csv')
# gustafson['t0'] = gustafson['ts0'] + gustafson['tp0']
# gustafson['f0'] = gustafson['ts0'] / gustafson['tp0']
# gustafson['t16'] = gustafson['ts16'] + gustafson['tp16']
# gustafson['f16'] = gustafson['ts16'] / gustafson['t16']
# gustafson['sp'] = gustafson['t0'] / gustafson['t16']
#
# gustafson_old = pd.read_csv('gustafson_old.csv')
# gustafson_old['t0'] = gustafson_old['ts0'] + gustafson_old['tp0']
# gustafson_old['f0'] = gustafson_old['ts0'] / gustafson_old['tp0']
# gustafson_old['t16'] = gustafson_old['ts16'] + gustafson_old['tp16']
# gustafson_old['f16'] = gustafson_old['ts16'] / gustafson_old['t16']
# gustafson_old['sp'] = gustafson_old['t0'] / gustafson_old['t16']
#
# plt.ylabel('S(P)')
# plt.xlabel('n')
# plt.plot(gustafson['n'], gustafson['sp'])
# plt.plot(gustafson_old['n'], gustafson_old['sp'])
# plt.axhline(y=16, color='r', linestyle='-')
# plt.title('Zależność przyspieszenia od wielkości problemu')
# plt.legend(['sp1', 'sp2','f(max)'])
# plt.show()





gustafson_old = pd.read_csv('gustafson_old.csv')
gustafson_old['t0'] = gustafson_old['ts0'] + gustafson_old['tp0']
gustafson_old['f0'] = gustafson_old['ts0'] / gustafson_old['tp0']

gustafson_old['t16'] = gustafson_old['ts16'] + gustafson_old['tp16']
gustafson_old['f16'] = gustafson_old['ts16'] / gustafson_old['t16']

gustafson_old['sp'] = gustafson_old['t0'] / gustafson_old['t16']


gustafson = pd.read_csv('gustafson.csv')
gustafson['t0'] = gustafson['ts0'] + gustafson['tp0']
gustafson['f0'] = gustafson['ts0'] / gustafson['tp0']

gustafson['t16'] = gustafson['ts16'] + gustafson['tp16']
gustafson['f16'] = gustafson['ts16'] / gustafson['t16']

gustafson['sp'] = gustafson['t0'] / gustafson['t16']


plt.ylabel('S(P)')
plt.xlabel('n')
plt.plot(gustafson_old['n'], gustafson_old['sp'])
plt.plot(gustafson['n'], gustafson['sp'])
plt.axhline(y=16, color='r', linestyle='--')
plt.title('Gustafson')
plt.show()