#!/usr/bin/python3

import matplotlib.pyplot as plt
import pandas as pd

amdhal = pd.read_csv('amdahal.csv', dtype=float)

amdhal['t'] = amdhal['ts'] + amdhal['tp']
amdhal['sp'] = amdhal['t'] / amdhal['tp']
amdhal['f'] = amdhal['ts'] / amdhal['t']
amdhal['sp'] = amdhal['t'][0] / amdhal['tp']

f = 1 / amdhal['f'][0]

plt.xlabel('P')
plt.ylabel('f')

plt.plot(amdhal['p'], amdhal['sp'])
plt.axhline(y=f, color='r', linestyle='--')
plt.title('Amdahal')
plt.show()


gustafson = pd.read_csv('gustafson.csv')
gustafson['t0'] = gustafson['ts0'] + gustafson['tp0']
gustafson['f0'] = gustafson['ts0'] / gustafson['tp0']

gustafson['t16'] = gustafson['ts16'] + gustafson['tp16']
gustafson['f16'] = gustafson['ts16'] / gustafson['t16']

gustafson['sp'] = gustafson['t0'] / gustafson['t16']

plt.ylabel('S(P)')
plt.xlabel('n')
plt.plot(gustafson['n'], gustafson['sp'])
plt.axhline(y=16, color='r', linestyle='--')
plt.show()

print(gustafson)